import { createContext, useReducer, useContext, useEffect } from "react";
// import { API } from "../global"
import reducer from "../Reducers/UserReducer";

const UserContext = createContext();

const userLocal = function getLocalData() {
  let id = sessionStorage.getItem("userId");
  let token = sessionStorage.getItem("userToken");
  let location = sessionStorage.getItem("userLocation");
  if (JSON.parse(token)) {
    return {
      userId: id,
      userToken: token,
      location: location || "",
    };
  } else {
    return {
      userId: "",
      userToken: "",
      location: "",
    };
  }
};

const initialState = {
  userId: userLocal.userId,
  user: {},
  userToken: userLocal.userToken,
  location: userLocal.location,
};

const UserProvider = ({ children }) => {
  const [state, dispatch] = useReducer(reducer, initialState);

  const setUser = (user, token) => {
    console.log(user);
    dispatch({ type: "SET_USER", payload: { user, token } });
  };

  // add data to local storage
  useEffect(() => {
    sessionStorage.setItem("userId", JSON.stringify(state.userId));
    sessionStorage.setItem("userToken", JSON.stringify(state.token));
    sessionStorage.setItem("userLocation", JSON.stringify(state.location));
    console.log(state);
  }, [state]);

  return (
    <UserContext.Provider value={{ ...state, setUser }}>
      {children}
    </UserContext.Provider>
  );
};

const useUserContext = () => {
  return useContext(UserContext);
};

export { UserProvider, useUserContext };

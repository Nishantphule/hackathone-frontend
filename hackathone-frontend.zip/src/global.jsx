export const API = "https://hackathone-backend.onrender.com";
